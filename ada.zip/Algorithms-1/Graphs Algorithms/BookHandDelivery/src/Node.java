public class Node {
    
    int person; // cada linha é uma pessoa
    int day; // dias variam de 0 a 7

    public Node(int person,int day) {
        this.person = person;
        this.day = day;
    }
}
