public class Problem {

    private char[][] matrix;

    public Problem(char[][] matrix) {
        this.matrix = matrix;
    }
    
}
