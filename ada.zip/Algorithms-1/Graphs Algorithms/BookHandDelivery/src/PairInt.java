public class PairInt implements Comparable<PairInt> {

    // o professor usou comparable neste exemplo
    // nao entendi bem porque
    // provavelmente para ver se é a mesma pessoa
    // mas isso é estupido

    // exemplo : para (John,Monday) o seu sucessores é identificado por
    // Node : (Mary,Monday) e o custo seria zero
    private Node node; // em vez de ser int
    private int cost; // este guardado o peso do arco

    public PairInt(Node node, int cost) {
        this.node = node;
        this.cost = cost;
    }

    public Node getNode() {
        return node;
    }

    public int getCost() {
        return cost;
    }

    @Override
    public int compareTo(PairInt o) {
        return cost - o.getCost();
    }

    

}
