import java.io.BufferedReader;
import java.io.InputStreamReader;

public class App {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int rows = Integer.parseInt(reader.readLine());
        char[][] matrix = new char[rows][7];
        for(int i = 0 ; i < rows; i++) {
            matrix[i] = reader.readLine().toCharArray();
        }

        Problem p = new Problem(matrix);
        
        int test_cases = Integer.parseInt(reader.readLine());
        for(int j = 0; j < test_cases; j++) {
            String[] array = reader.readLine().split(" ");
            int source = Integer.parseInt(array[0]);
            int destination = Integer.parseInt(array[1]);

        }
    }
}
