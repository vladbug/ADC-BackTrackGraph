import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] param = reader.readLine().split(" ");
        int regions = Integer.parseInt(param[0]);
        int links = Integer.parseInt(param[1]);

        Problem p = new Problem(regions);

        for(int i = 1; i <= regions; i++) {
            param = reader.readLine().split(" ");
            int population = Integer.parseInt(param[0]);
            int capacity = Integer.parseInt(param[1]);
            p.addInformation(population, capacity, i);
        }

        p.addReplicas();

        for(int i = 0; i < links; i++) {
            param = reader.readLine().split(" ");
            int origin = Integer.parseInt(param[0]);
            int destination = Integer.parseInt(param[1]);
            p.addRule(origin, destination);
        }

        int safeCity = Integer.parseInt(reader.readLine());
        int solution = p.solve(safeCity);
        System.out.println(solution);


    }
}
