import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Problem {

    private static final int INF = Integer.MAX_VALUE;
    private int regions;
    private int numNodes;

    private List<Edge>[] sucessores;

    private int[] population; // queimar 0
    private int[] capacity;

    @SuppressWarnings("unchecked")
    public Problem(int regions) {
        this.numNodes = regions;
        this.regions = (regions*2)+1;
        
        sucessores = new List[this.regions];
        population = new int[regions+1];
        capacity = new int[regions+1];

        for(int i = 0; i < this.regions; i++) {
            sucessores[i] = new LinkedList<Edge>();
        }

    }

    // 0 1 2 3 4 5 1' 2' 3' 4' 5'
    // 0 1 2 3 4 5 6  7  8  9  10

    public void addInformation(int population, int capacity, int node) {
        this.population[node] = population;
        this.capacity[node] = capacity;
        sucessores[0].add(new Edge(0,node,population));
    }

    public void addReplicas() {
        for(int i = 1; i <= numNodes; i++) {
            sucessores[i].add(new Edge(i,numNodes+i,capacity[i]));
        }
    }

    public void addRule(int source, int destination) {
        // i -> original
        // i + 1 -> original'
        sucessores[source+numNodes].add(new Edge(source+numNodes,destination,INF)); //2' -> 4
        sucessores[destination+numNodes].add(new Edge(destination+numNodes,source,INF)); //4' -> 2
    }

    public int solve(int sink) {
        buildNetwork();
        int source = 0;
        int numNodes = sucessores.length;

        // Java já mete tudo a zeros
        int[][] flow = new int[numNodes][numNodes];

        int[] via = new int[numNodes];
        int flowValue = 0;
        int increment;

        while((increment = findPath(flow,source,sink,via)) != 0) {
            flowValue += increment;
            // Update flow
            int node = sink;
            while(node != source) {
                int origin = via[node];
                flow[origin][node] += increment;
                flow[node][origin] -= increment;
                node = origin;
            }
        }

        return flowValue;
        }
        
        
    private int findPath(int[][] flow, int source, int sink, int[] via) {

        int numNodes = regions;

        Queue<Integer> waiting = new LinkedList<Integer>();

        boolean[] found = new boolean[numNodes];

        int[] pathIncr = new int[numNodes];

        waiting.add(source);
        
        found[source] = true;

        via[source] = source;

        pathIncr[source] = INF;

        do {

            int origin = waiting.remove();

            for(Edge e : sucessores[origin]) {
                int destin = e.getDestination();
                int residue = e.getCost() - flow[origin][destin];
                if(!found[destin] && residue > 0) {
                    via[destin] = origin;
                    pathIncr[destin] = Math.min(pathIncr[origin], residue);
                    if(destin == sink)
                        return pathIncr[destin];
                    waiting.add(destin);
                    found[destin] = true;
                }
            }


        } while(!waiting.isEmpty());
        return 0;
    }

    private void buildNetwork() {
        // Para adicionar vertices com peso zero
        for(List<Edge> l : sucessores) { // 0' -> 2 || 2' -> 0
            for(Edge e : l) {
                int node1 = e.getSource();
                int node2 = e.getDestination();
                if(!sucessores[node2].contains(new Edge(node2,node1,e.getCost()))) {
                    sucessores[node2].add(new Edge(node2,node1,0)); // isto muito provavelmente está mal, mas nao queria pensar afundo
                }
            }
        }

    }



    
}
