/**
 * @author Ricardo Silva 60559 & Vladyslav Mikytiv 60735
 */

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] param = reader.readLine().split(" ");
        int rows = Integer.parseInt(param[0]);
        int cols = Integer.parseInt(param[1]);
        int testCases = Integer.parseInt(param[2]);
        char[][] matrix = new char[rows + 1][cols + 1]; // queimamos o zero
        for(int i = 1; i <= rows; i++) {
             String concat = ' ' + reader.readLine();
             matrix[i] = concat.toCharArray();
        }

        Problem p = new Problem(matrix);

        for(int i = 0; i < testCases; i++) {
            String[] startPos = reader.readLine().split(" ");
            System.out.println(p.solve(Integer.parseInt(startPos[0]), Integer.parseInt(startPos[1])));
        }
        reader.close();
    }

    

    

}
