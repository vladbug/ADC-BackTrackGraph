/**
 * @author Ricardo Silva 60559 & Vladyslav Mikytiv 60735
 */
import java.util.LinkedList;
import java.util.Queue;


public class Problem {

    private char[][] matrix;
    int rows, cols;

    private int rowNum[] = { -1, 0, 0, 1 };
    private int colNum[] = { 0, -1, 1, 0 };

    private Pair[][] grafo;

    public Problem(char[][] matrix) { 
        this.matrix = matrix;
        rows = matrix.length;
        cols = matrix[0].length;
        grafo = new Pair[rows*cols][]; // We know how many succs each node will have
    }

    private boolean outOfBounds(int x, int y) {
        return (x == rows || y == cols || x == 0 || y == 0);
    }

    private Pair traversePath(int x, int y, int xDiff, int yDiff) {

        while (!outOfBounds(x + xDiff, y + yDiff)) {
            if (matrix[x + xDiff][y + yDiff] == 'H') {
                return new Pair(x + xDiff, y + yDiff);
            }

            if (matrix[x + xDiff][y + yDiff] == 'O') {
                return new Pair(x, y);
            } else { // Walk
                x += xDiff;
                y += yDiff;
            }
        }
        return new Pair(-1, -1);

    }


    public String solve(int x, int y) {
        int steps = 0;

        boolean[][] found = new boolean[rows][cols];

        Queue<Pair> current_level = new LinkedList<>();
        Queue<Pair> next_level = new LinkedList<>();
        Pair source = new Pair(x, y);
        current_level.add(source);
        found[x][y] = true;

        while (!current_level.isEmpty()) {

            Pair current = current_level.remove();
            Pair[] succ = grafo[hashPair(current)];
            
            if(succ == null) { // It's succs aren't in the graph yet

                succ = new Pair[4];
                for (int i = 0; i < 4; i++) { // Explore the 4 different directions
                    Pair p = traversePath(current.getX(), current.getY(), rowNum[i], colNum[i]);
                    succ[i] = p;
                }

                int key = hashPair(current);
    
                grafo[key] = succ;
            }

            for(Pair p : succ) { // Will execute exactly 4 times , get succs

                if(p.getX() != -1) {
                    if (matrix[p.getX()][p.getY()] == 'H') {
                        return Integer.toString(steps+1);
                    } else if (!found[p.getX()][p.getY()]) {
                        found[p.getX()][p.getY()] = true;
                        next_level.add(p);

                    }
                }
            }

            if (current_level.isEmpty()) {
                // Swap levels, each level is a step
                steps++;
                Queue<Pair> aux = current_level;
                current_level = next_level;
                next_level = aux;
            }
        }
        return "Stuck";
    }

    public int hashPair(Pair p) {
        return cols * (p.getX()-1) + (p.getY()-1);
    }


}
