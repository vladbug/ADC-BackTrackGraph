public class Problem {
    final int[] legoSizes = {1,2,3,4,6,8,10,12,16};
    int currSize;
    public Problem() {
        
    }

    public int p(int n) {
        currSize = 0;
        // getNextValidSize(currSize);
        return solve(n); //n = 4
    }

    //Sizes: 1 2 3 4 6 8
    private int solve(int n) { // n = 1
        int validSize = getNextValidSize(currSize);
        int maxSize = n - validSize;
        
        if(maxSize < 0) {
            return 0;
        }
        
        int w = w(maxSize);
        
        return w + solve(n);
    }

    /* 1 2 3 4 6
         * 6-1 >= 0 w(5) = W(4)
         * 6-2 >= 0 w(5) = W(4) + W(3)
         * 5-3 >= 0 w(5) = W(4) + W(3) + W(2)
         * 5-4 >= 0 w(5) = W(4) + W(3) + W(2) + W(1)
         * 5-6 >= 0 w(6) = W(5) + W(4) + W(3) + W(2) + W(0)
         */

    public int w(int i) {
        if(i == 0) {
            return 1;
        }
        int result = 0;
        int index = 0;
        while (i-legoSizes[index] >= 0) {
            result += w(i-legoSizes[index]);
            index++;
        }
        return result;
    }

    private int getNextValidSize(int i) {
        if(currSize == 8) {
            return legoSizes[currSize];
        } else {
            int sizeReturn = legoSizes[currSize];
            currSize++;
            
            return sizeReturn;
        }
        
    }

    


    
}
