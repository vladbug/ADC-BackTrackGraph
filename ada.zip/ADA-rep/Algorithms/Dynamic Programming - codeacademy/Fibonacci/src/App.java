public class App {
    public static void main(String[] args) throws Exception {
        System.out.println(fibTab(100));
    }

    // If we call this function with n = 100 it will take A LOT of time to execute
     
    public static int fibRecursive(int n) {

        int result;

        if(n == 0 || n == 1) {
            result = n;
        }

        else {
            result = fibRecursive(n-1) + fibRecursive(n-2);
        }

        return result;
    }

    // Let's do it better in order to use stored data 
    // Technique : memoization , store duplicate problems

    public static long fibMem(int n) {

        long[] tab = new long[n+1];
        for(int i = 0; i <= n; i++) {
            tab[i] = -1;
        }

        return fibMem(tab,n);
    }

    public static long fibMem(long[] tab,int n) {

        if(tab[n] == -1) {
            if(n == 0 || n == 1) {
                tab[n] = n;
            } 
            else {
                // Instead of returning it as a recursive call, we do it and we store
                // What this does is that when we find again a value
                // that is in the table we just return it
                tab[n] = fibMem(tab,n-1) + fibMem(tab,n-2);          
        }
    }
        return tab[n];
    }


    // Tabulation method

    public static long fibTab(int n) {

        long[] tab = new long[n+1];

        tab[0] = 0;
        tab[1] = 1;

        for(int i = 2; i <= n; i++) {
           tab[i] = tab[i-1] + tab[i-2];
        }

        return tab[n];

    }



}
