import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
        int[] test = {1,2,5,25};
        System.out.println(bestSumMem(100, test));
    }

    // It is slow with big examples
    public static List<Integer> bestSum(int target, int[] numbers) {

        if(target == 0) return new LinkedList<>();

        if(target < 0) return null;

        List<Integer> shortestCombination = null;

        for(int i = 0; i < numbers.length; i++) {
            int remainder = target - numbers[i];
            List<Integer> remainderCombination = bestSum(remainder,numbers);

            // It is possible to generate the remainder
            if(remainderCombination != null) {
                remainderCombination.add(numbers[i]); 
                List<Integer> a = remainderCombination;
                if(shortestCombination == null || a.size() < shortestCombination.size()) {
                    shortestCombination = a;
                }


            }

        }

        return shortestCombination;
    }

    public static List<Integer> bestSumMem(int target, int[] numbers) {

        Map<Integer,List<Integer>> mem = new HashMap<>();
        return bestSumMem(target,numbers,mem);
    }

    public static List<Integer> bestSumMem(int target, int[] numbers, Map<Integer,List<Integer>> mem) {

        if(mem.containsKey(target)) return mem.get(target);

        if(target == 0) return new LinkedList<>();

        if(target < 0) return null;

        List<Integer> shortestCombination = null;

        for(int i = 0; i < numbers.length; i++) {
            int remainder = target - numbers[i];
            List<Integer> remainderCombination = bestSumMem(remainder,numbers,mem);
            
            // It is possible to generate the remainder
            if(remainderCombination != null) {
                List<Integer> newCombination = new LinkedList<>(remainderCombination);
                newCombination.add(numbers[i]);
                if(shortestCombination == null || newCombination.size() < shortestCombination.size()) {
                    shortestCombination = newCombination;
                   
                }


            }

        }
        mem.put(target, shortestCombination);
        return shortestCombination;

    }






}
