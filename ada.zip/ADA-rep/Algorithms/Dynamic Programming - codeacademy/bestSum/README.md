## bestSum

Write a function `bestSum(targetSum,numbers)` that takes in a targetSum and an array
of numbers as arguments.

The function should return an array contatining the `shortest` combination
of numbers that add up to exactly the targetSum.

If there is a tie for the shortes combination, you may return any one of the
shortest.


