import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
        int[] test = {7,14};
        System.out.println(canSumMem(600, test));
    }

    // It is fast but still is slow. We can do better
    public static boolean canSum(int target, int[] numbers) {

        if(target == 0) return true;

        // We just went too far, nothing else that we can add to fix that sum
        if(target < 0) return false;
        
        for(int i = 0; i < numbers.length; i++) {

            int remainder = target - numbers[i];

            // If we find at least one way we do an early return
            if ( canSum(remainder,numbers) ) return true;
        }

        return false;

    }

    public static boolean canSumMem(int target, int[] numbers) {
        Map<Integer,Boolean> mem = new HashMap<>();
        return canSumMem(target, numbers,mem);
    }

    public static boolean canSumMem(int target, int[] numbers, Map<Integer,Boolean> mem) {
        if(target == 0) return true;
        if(mem.containsKey(target)) return mem.get(target);
        // We just went too far, nothing else that we can add to fix that sum
        if(target < 0) return false;
        
        for(int i = 0; i < numbers.length; i++) { 

            int remainder = target - numbers[i];

            // If we find at least one way we do an early return
            if ( canSumMem(remainder,numbers,mem) ) {
                mem.put(target,true);
                return true;
            } 
        }
        mem.put(target,false);
        return false;
    }
}
