import java.util.*;

public class App {
    public static void main(String[] args) throws Exception {
        int[] test = {7,14};
        System.out.println(howSumMem(300,test));
    }

    public static List<Integer> howSum(int target, int[] numbers) {

        if(target == 0) return new LinkedList<>();
       
        if(target < 0) return null;

        for( int i = 0; i < numbers.length; i++) {
            int remainder = target - numbers[i];
            List<Integer> remainderResult = howSum(remainder,numbers);

            // It is possible to generate the remainder
            if(remainderResult != null) {
                remainderResult.add(numbers[i]);
                return remainderResult;
            }
        }

        return null;

    }

    public static List<Integer> howSumMem(int target, int[] numbers) {

        Map<Integer,List<Integer>> mem = new HashMap<>();
        return howSumMem(target,numbers,mem);

    }

    public static List<Integer> howSumMem(int target, int[] numbers, Map<Integer,List<Integer>> mem) {

        if(mem.containsKey(target)) {
            return mem.get(target);
        }
        if(target == 0) return new LinkedList<>();
       
        if(target < 0) return null;

        for( int i = 0; i < numbers.length; i++) {
            int remainder = target - numbers[i];
            List<Integer> remainderResult = howSumMem(remainder,numbers,mem);

            // It is possible to generate the remainder
            if(remainderResult != null) {
                remainderResult.add(numbers[i]);
                mem.put(target, remainderResult);
                return remainderResult;
            }
        }
        mem.put(target, null);
        return null;

    }
}
 