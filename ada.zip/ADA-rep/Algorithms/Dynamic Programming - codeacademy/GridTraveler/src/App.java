import java.util.*;

public class App {


    public static void main(String[] args) throws Exception {
        System.out.println(gridMem(18, 18));
    }

    // Brute force recursion , takes A LOT of time
    public static int gridTraveler(int m, int n) {

        if(m == 1 && n == 1) return 1; 
        if(m == 0 || n == 0) return 0;

        // Move down m -1 && Move right n - 1
        return gridTraveler(m-1, n) + gridTraveler(m, n-1);

    }

    public static long gridMem(int m, int n) {

        Map<String,Long> mem = new HashMap<>();
        return gridMem(m,n,mem);
    }

    public static long gridMem(int m, int n, Map<String,Long> mem) {

        String key = m + "." + n;

        // if(mem.containsKey(key)) {
        //     return mem.get(key);
        // }

        // if(m == 1 && n == 1) return 1;
        // if(m == 0 || n == 0) return 0;

        // mem.put(key,gridMem(m-1,n,mem) + gridMem(m,n-1,mem));

        // return mem.get(key);


        Long a = mem.get(key);

        if( a == null) {

            if(m == 1 && n == 1) return 1;
            if(m == 0 || n == 0) return 0;

           
            // alternative
            a = gridMem(m-1, n, mem) + gridMem(m, n-1, mem);
            mem.put(key, a);

        }

        return a;
    }

}
