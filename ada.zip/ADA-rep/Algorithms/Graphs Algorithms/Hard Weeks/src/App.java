import java.io.*;


public class App {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] param = reader.readLine().split(" ");
        int number_of_tasks = Integer.parseInt(param[0]);
        int number_of_edges = Integer.parseInt(param[1]);
        int limit = Integer.parseInt(param[2]);

        Problem e = new Problem(number_of_tasks,limit);

        for(int i = 0; i < number_of_edges; i++) {
            String[] in = reader.readLine().split(" ");
            e.addRule(Integer.parseInt(in[0]),Integer.parseInt(in[1]));
        }

        e.solve();
        System.out.println(e.getMax() + " : " + e.getHardWeeks());

    }
}



