import java.util.*;

public class Problem {

    List<Integer>[] sucessores;
    int[] inDegree; //Nr de Antecessores
    Queue<Integer> current_week;
    Queue<Integer> next_week;

    private int limit;
    private int max;
    private int hard_weeks;

    @SuppressWarnings("unchecked")
    public Problem(int tasks, int limit) {

        sucessores = new List[tasks];
        inDegree = new int[tasks]; // ja fica com zeros
        current_week = new LinkedList<>();
        next_week = new LinkedList<>();
        this.limit = limit;
        hard_weeks = 0;
        max = Integer.MIN_VALUE;
    
        // Importante fazer assim !
        for(int i = 0; i < tasks; i++) {
            sucessores[i] = new LinkedList<Integer>();
        }
    }

    //Adiciona regras de precedencia e inicializa o nr de antecessores
    public void addRule(int source, int destination) {
        sucessores[source].add(destination);
        inDegree[destination]++;
    }

    private void calculateFirstWeek() {
        //Adicionamos as tarefas com 0 antecessores ao plano semanal
        for(int i = 0; i < inDegree.length; i++) {
            if(inDegree[i] == 0) {
                current_week.add(i);
            }
        }

        //Atualizamos o max de tarefas numa semana
        if(current_week.size() > max) {
            max = current_week.size();
        }

        //Vemos se é uma hard week
        if(current_week.size() > limit) {
            hard_weeks++;
        }
    }

    public void solve() {

        //Inicializamos a primeira semana de trabalho
        calculateFirstWeek();

        //Enquanto houver tarefas para fazer
        while(!current_week.isEmpty()) {
            
            //Removemos uma tarefa da queue
            int x = current_week.remove();
            
            //Para cada um dos seus sucessores
            for(Integer y : sucessores[x]) {
                //Dizemos que tem menos 1 antecessor
                inDegree[y]--;

                //Se eles ficarem tarefas válidas, adicionamos
                //ao plano semanal da PRÓXIMA semana
                if(inDegree[y] == 0) {
                    next_week.add(y);
                }
            }

            //Se terminamos a nossa semana, trocamos para a próxima
            if(current_week.isEmpty()) {

                //Swap
                Queue<Integer> temp = current_week;
                current_week = next_week;
                next_week = temp;

                //Atualizamos o Max de tarefas com a nossa nova semana
                if(current_week.size() > max) {
                    max = current_week.size();
                }
        
                //Vemos se é uma hard week
                if(current_week.size() > limit) {
                    hard_weeks++;
                }

            }
        }
    }

    public int getMax() {
        return max;
    }

    public int getHardWeeks() {
        return hard_weeks;
    }
}
