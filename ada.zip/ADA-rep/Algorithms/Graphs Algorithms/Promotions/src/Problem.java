import java.util.*;

public class Problem {

    //Dados problema
    private int lowerBound,upperBound,empregados;

    List<Integer>[] successors, predecessors;

    int[] numberOfSucessores;
    int[] numberOfAntecessores;

    boolean[] processed;

    @SuppressWarnings("unchecked")
    public Problem(int empregados, int lowerBound, int upperBound) {

        successors = new List[empregados];
        predecessors = new List[empregados];
        numberOfSucessores = new int[empregados];
        numberOfAntecessores = new int[empregados];
        processed = new boolean[empregados];

        this.empregados = empregados;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;

        // Importante fazer assim !
        for(int i = 0; i < empregados; i++) {
            successors[i] = new LinkedList<Integer>();
            predecessors[i] = new LinkedList<Integer>();
        }
    }

    //Adiciona regras de antecessores
    public void addRule(int source, int destination) {
        successors[source].add(destination);
        predecessors[destination].add(source);
    }

    //Conta os sucessores/antecessores de cada um
    private void fillArrays() {
        for(int i = 0; i < empregados; i++) {
            numberOfSucessores[i] = countSucessores(processed,i);
            processed = new boolean[empregados];
            numberOfAntecessores[i] = countAntecessores(processed, i);
            processed = new boolean[empregados];
        }
    }

    public int[] solve() {
        fillArrays();
        int[] toReturn = new int[upperBound-lowerBound + 2];
        int counter = 0;
        int index = 0;

        // Promoted
        for(int promotionSlots = lowerBound; promotionSlots <= upperBound; promotionSlots++) { //Para as duas vagas
            for(int j = 0; j < empregados; j++) { //Para cada empregado
                int number_of_suc = numberOfSucessores[j];
                //Nr pessoas que podem ser promovidas "em vez de mim"
                int promotionOptions = empregados - number_of_suc;

                //Se houver vagas suficientes
                if(promotionOptions <= promotionSlots) {
                    counter++; //Garantido
                } 
            }
            toReturn[index++] = counter;
            counter = 0;
        }
     
        // Nao promoted
        for(int i = 0; i < empregados; i++) {
            int number_of_pre = numberOfAntecessores[i];
            if(upperBound <= number_of_pre) {
                counter++;
            }
        }

        toReturn[index] = counter;
        return toReturn;
    }

    //Isto calcula os antecessores totais, não apenas os antecessores diretos
    //Recursivamente calcula os antecessores dos antecessores
    private int countAntecessores(boolean[] processed, int root) {
        //DFS que conta os nós que encontra
        int res = 0;

        processed[root] = true;

        for(Integer a : predecessors[root]) {

            if(!processed[a]) {
                res += 1 + countAntecessores(processed, a);
            }
        }

        return res;

    }

    private int countSucessores(boolean[] processed, int root) {
        //DFS que conta os nós que encontra
        int res = 0;

        processed[root] = true;

        for(Integer a : successors[root]) {

            if(!processed[a]) {
                res += 1 + countSucessores(processed, a);
            }
        }

        return res;

    }

}
