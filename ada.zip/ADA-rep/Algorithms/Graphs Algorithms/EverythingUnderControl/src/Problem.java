import java.util.*;

public class Problem {
    
    int nrNodes;
    // Nó inicial, representa o nó 1 isolado
    // Vai ter 1 -(0)-> 1
    Edge initialNode;

    //Pior custo possível até ao nó
    int[] worstCost;

    //Nr Antecessores para cada nó
    int[] inDegree;

    List<Edge>[] successores;

    // Result, nodes that can be postponed
    List<Edge> postponed;

    @SuppressWarnings("unchecked")
    public Problem(int nrNodes) {

        this.nrNodes = nrNodes;
        this.initialNode = new Edge(1,1,0);
        
        worstCost = new int[nrNodes+1];
        inDegree = new int[nrNodes+1];

        postponed = new LinkedList<>();
        successores = new List[nrNodes+1];

        // Importante fazer assim ! 
        for(int i = 1; i <= nrNodes; i++) {
            successores[i] = new LinkedList<Edge>();
        }
    }

    //Adiciona regras de antecessores
    public void addRule(int source, int destination, int cost) {

        //Sucessor vai guardar arcos, que ligam o próprio até ao destino
        successores[source].add(new Edge(source, destination, cost));
        inDegree[destination]++;
    }

    //Vai calcular os custos máximos para chegar a cada nó
    private void getMaxCosts() {

        // Estutura auxiliar para o topological sort
        Queue<Edge> ready = new LinkedList<>();

        // Começamos no nó inicial
        ready.add(initialNode);

        //Enquanto houver arcos no saco
        while(!ready.isEmpty()) {

            //Removemos um arco do saco
            Edge edge = ready.remove();

            // Para cada arco que representam os sucessores (vamos buscar o do destino porque começamos a iterar o algoritmo
            // já a assumir que iteramos os anteriores). Começamos no nó inicial que já foi calculado.
            for(Edge e : successores[edge.getDestination()]) {

                // Vamos ver o máximo entre o valor tabelado e o nosso novo caminho (custo até source + custo da tarefa )
                worstCost[e.getDestination()] = Math.max(worstCost[e.getDestination()], worstCost[e.getSource()] + e.getCost());

                //Ja fiz esta tarefa, removo um precedente
                inDegree[e.getDestination()]--;

                // Se já fiz todas as outras tarefas até mim, significa que já tenho o maxCost() correto e posso então explorar os
                // sucessores deste nó
                if(inDegree[e.getDestination()] == 0)
                    ready.add(e);
            }
        }
    }

    public List<Edge> solve() {
        getMaxCosts();

        // Para cada arco no grafo
        for(List<Edge> l : successores) {
            if(l != null) {
                for(Edge e : l) {

                    // Se o meu caminho (custo até mim + custo do arco) for mais baixo que o pior possível do meu destino
                    // Quer dizer que sou adiável
                    if(worstCost[e.getSource()] + e.getCost() < worstCost[e.getDestination()])
                        postponed.add(e);
                }
            }
        }

        //Ordem crescente
        Collections.sort(postponed);

        return postponed;
    }

    /* Para cada um dos arcos que representam os sucessores
    * O custo máximo do nó destino 1 --> 2 (destino: 2)
    * Vai ser o máximo entre o valor anterior e o custo até à origem e.getSource() + o custo do arco
    * Ou seja, o custo até ao nó 1 + o custo do arco. Representa um caminho possível até ao nó 2
    *   worstCost[e.getDestination()] = Math.max(worstCost[e.getDestination()], worstCost[e.getSource()] + e.getCost());
    */
}
