import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] param = reader.readLine().split(" ");
        int numberOfNodes = Integer.parseInt(param[0]);
        int number_of_edges = Integer.parseInt(param[1]);

        Problem p = new Problem(numberOfNodes);

        for(int i = 0; i < number_of_edges; i++) {
            param = reader.readLine().split(" ");
            int source = Integer.parseInt(param[0]);
            int destination = Integer.parseInt(param[1]);
            int cost = Integer.parseInt(param[2]);
            p.addRule(source, destination, cost);
        }

        List<Edge> solution = p.solve();
        System.out.println(solution.size());
        for(Edge e : solution) {
            System.out.println(e.getSource() + " " + e.getDestination());
        }


    }
}
