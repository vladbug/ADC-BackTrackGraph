import java.util.LinkedList;
import java.util.List;

public class Problem {

    private int numberOfNodes;

    List<Edge> edges;
    
    public Problem(int numberOfNodes) {
        this.numberOfNodes = numberOfNodes;
        edges = new LinkedList<>();
    }

    public void addRule(int source, int destination, int value) {
        edges.add(new Edge(source,destination,value));
    }

    // passamos ao contrario na main
    public int solve(int fonte, int dreno, int I) {

        int[] length = new int[numberOfNodes];
        int[] via = new int[numberOfNodes];

        for(int i = 0; i < length.length; i++) {
            length[i] = Integer.MAX_VALUE;
        }

        length[fonte] = 0;
        via[fonte] = fonte;

        boolean changes = false;

        for(int i = 1; i < numberOfNodes; i++) {
            changes = updateLengths(length,via);
            if(!changes) {
                break;
            }
        }

        if(changes && updateLengths(length,via)) {
            return -1;
        }

        if(length[dreno] < 0) {
            return -1;
        }

        if(I - length[dreno] < 0) {
            return 0;
        }

        
        return I - length[dreno];
    }

    private boolean updateLengths(int[] len, int[] via) {

        boolean changes = false;

        for(Edge e : edges) {
            int tail = e.getSource();
            int head = e.getDestination();

            if(len[tail] < Integer.MAX_VALUE) {
                int newLen = len[tail] + e.getCost();
                if(newLen < len[head]) {
                    len[head] = newLen;
                    via[head] = tail;
                    changes = true;
                }
            }
        }

        return changes;
    }


}
