public class Edge implements Comparable<Edge>{

    private int source;
    private int destination;
    private int cost;

    public Edge(int source, int destination, int cost) {
        this.source = source;
        this.destination = destination;
        this.cost = cost;
    }

    public int getSource() {
        return source;
    }

    public int getDestination() {
        return destination;
    }

    public int getCost() {
        return cost;
    }

    @Override
    public int compareTo(Edge o) {
        if(this.source < o.getSource()) {
            return -1;
        }

        if(this.source == o.getSource()) {
            return this.destination - o.getDestination();
        }

        return 1;
    }



    
}