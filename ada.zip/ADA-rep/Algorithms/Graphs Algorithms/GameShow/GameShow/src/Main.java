import java.beans.DesignMode;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] param = reader.readLine().split(" ");
        int numberOfNodes = Integer.parseInt(param[0]);
        int number_of_edges = Integer.parseInt(param[1]);

        Problem p = new Problem(numberOfNodes);

        for(int i = 0; i < number_of_edges; i++) {
            param = reader.readLine().split(" ");
            int source = Integer.parseInt(param[0]);
            int destination = Integer.parseInt(param[1]);
            int value = Integer.parseInt(param[2]);
            p.addRule(destination, source,-value);
        }

        param = reader.readLine().split(" ");
        int source = Integer.parseInt(param[0]);
        int destination = Integer.parseInt(param[1]);
        int prize = Integer.parseInt(param[2]);

        int result = p.solve(destination,source,prize);
       
        if( result < 0) {
            System.out.println("Out of budget");
        } else {
            System.out.println(result);
        }

        

       
    }
}
