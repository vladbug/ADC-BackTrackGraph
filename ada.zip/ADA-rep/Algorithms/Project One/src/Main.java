import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * @author Ricardo Silva 60559
 * @author Vladyslav Mikytiv 60735
 */

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
        int test_cases = Integer.parseInt(reader.readLine());
		
        for(int i = 0; i < test_cases; i++) {
            String route = reader.readLine();
            char[] r = route.toCharArray();
            Problem p = new Problem(r);
            System.out.println(p.solve());
        }
    }
}
