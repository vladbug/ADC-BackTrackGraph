/**
 * @author Ricardo Silva 60559
 * @author Vladyslav Mikytiv 60735
 */

public class Problem {

    private static final int HARP_COST = 4;
    private static final int POTION_COST = 5;
    private static final int CLOAK_COST = 6;
    
    private static final int BASE_WALKING_COST = 1;
    private static final int ITEM_WALK_COST = 3;
    private static final int ITEM_SWAP_COST = 3;
    private static final int ITEM_DROP_COST = 2;
    
    private char[] route;
    private int[][] table;

    private static int INF = 6 * 100000; // para nao estarmos sempre a verificar se arrebenta ou nao
    // 6 * 100 000
    
    public Problem(char[] route) {
        this.route = route;
        table = new int[2][4];
    }

    public int solve() {


        for(int j = 3; j >= 0; j--) {
            char plot = route[route.length-1];
            if( ( plot == 'e' || hasItem(plot) ) && j == 0) {
                table[1][j] = BASE_WALKING_COST;
            }else if((plot == 'e' || hasItem(plot)) && j != 0) {
                table[1][j] = ITEM_DROP_COST;
            } else if(plot == '3' && j == 1) {
                table[1][j] = HARP_COST;
            } else if((plot == '3' || plot == 't') && j == 2) {
                table[1][j] = POTION_COST;
            } else if((hasMonster(plot)) && j == 3) {
                table[1][j] = CLOAK_COST;
            }
            else {
                table[1][j] = INF; 
            }
        }

       
        for(int i = route.length-2; i >= 0; i--) { 
            for(int j = 3; j >= 0; j--) { 

                if(hasMonster(route[i])) {
                    if(j == 3) {
                        table[0][j] = CLOAK_COST + table[1][j];
                    }  
                    else if(j == 2 && (route[i] == '3' || route[i] == 't')) {
                        table[0][j] = POTION_COST + table[1][j];
                    }
                    else if(j == 1 && (route[i] == '3')) {
                        table[0][j] = HARP_COST + table[1][j];
                    }    
                    else {
                        table[0][j] = INF;
                    }
                // Caso onde há um item no plot
                } else if(hasItem(route[i])) {
                    // Há um item no chão e nós temos algo na mão (j != 0)
                    if(j != 0) {
                        // Mínimo entre: Andar com o item que temos na mão || Trocar com o item no chão || Largar o item que temos na mão e continuar
                        table[0][j] = Math.min( ITEM_WALK_COST + table[1][j],Math.min( ITEM_SWAP_COST + table[1][computeIndex(route[i])], ITEM_DROP_COST + table[1][0]));
    
                    // Há um item no chão e nós não temos nada na mão (j == 0)
                    } else {
                        // Mínimo entre: Continuar sem o item || Apanhar o item do chão
                        table[0][j] = Math.min(1+table[1][j],2+table[1][computeIndex(route[i])]);
                    }
                } 
                // Caso onde há um easy plot
                else {
                    // Se tivermos um item na mão (j != 0)
                    if(j != 0) {
                        // Mínimo entre: Largar o item que temos na mão || Continuar com o item que temos na mão
                        table[0][j] = Math.min( ITEM_DROP_COST + table[1][0], ITEM_WALK_COST + table[1][j]);
                    // Se não tivermos um item na mão (j == 0 )
                    } else {
                        // Continuamos a andar
                        table[0][j] = BASE_WALKING_COST + table[1][0];
                    }
                }        
            }
            //Troca das linhas da tabela
            table[1] = table[0];
            table[0] = new int[4];
        }  
       return table[1][0];
    }

    //Devolve true se no plot houver um monstro
    private boolean hasMonster(char x) {
        return (x == 't' || x == '3' || x == 'd');
    }

    //Devolve true se no plot houver um item
    private boolean hasItem(char x) {
        return (x == 'h' || x == 'p' || x == 'c');
    }

    //Converte um caracter no seu índice correspondente
    private int computeIndex(char x) {
        // e = column 0, h = column 1, p = column 2, c = column 3
        if(x == 'e') {
            return 0;
        }else if(x == 'h') {
            return 1;
        }else if(x == 'p') {
            return 2;
        }else if(x == 'c') {
            return 3;
        } else {
            return -1;
        }

    }

}
