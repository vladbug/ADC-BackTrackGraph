public class Edge {

    // 1 -(3)- 2
    // pred : 1
    // succ : 2
    // cost : 3
    private int source;
    private int destination;
    private int cost;

    public Edge(int source, int destination, int cost) {
        this.source = source;
        this.destination = destination;
        this.cost = cost;
    }

    public int getSource() {
        return source;
    }

    public int getDestination() {
        return destination;
    }

    public int getCost() {
        return cost;
    }

    
}
