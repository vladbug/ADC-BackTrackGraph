import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String[] param = reader.readLine().split(" ");
        int regions = Integer.parseInt(param[0]);
        int links = Integer.parseInt(param[1]);
        int[] population = new int[regions + 1]; // queimar 0
        int[] capacity = new int[regions +1];

        // for(int i = 1; i <= regions; i++) {
        //     param = reader.readLine().split(" ");
        //     int population = Integer.parseInt(param[0]);
        //     int capacity = Integer.parseInt(param[1]);
        //     p.addInformation(population, capacity, i);
        // }

        for(int i = 1; i <= regions; i++) {
            param = reader.readLine().split(" ");
            population[i] = Integer.parseInt(param[0]);
            capacity[i] = Integer.parseInt(param[1]);
        }

        Problem p = new Problem(population,capacity);

        for(int i = 0; i < links; i++) {
            param = reader.readLine().split(" ");
            int origin = Integer.parseInt(param[0]);
            int destination = Integer.parseInt(param[1]);
            p.addRule(origin, destination);
        }

        int safeCity = Integer.parseInt(reader.readLine());
        int solution = p.solve(safeCity);
        System.out.println(solution);


    }
}
