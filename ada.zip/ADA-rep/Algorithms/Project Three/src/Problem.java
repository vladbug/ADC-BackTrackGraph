import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Problem {

    private static final int INF = Integer.MAX_VALUE;
    private int regions;
    private int numNodes;

    private List<Edge>[] sucessores;

    private int[] population; // queimamos o zero
    private int[] capacity; // queimamos o zero

    @SuppressWarnings("unchecked")
    public Problem(int[] population, int[] capacity) {

        this.numNodes = population.length-1;

        
        this.regions = (numNodes*2)+1;
        
        sucessores = new List[this.regions];
        this.population = population; 
        this.capacity = capacity;

        for(int i = 0; i < this.regions; i++) {
            sucessores[i] = new LinkedList<Edge>();
        }

        addArtificialNodes();

    }

    // 0 1 2 3 4 5 1' 2' 3' 4' 5'
    // 0 1 2 3 4 5 6  7  8  9  10

    private void addArtificialNodes() {
        //int j = 0;

        for(int i = 1; i <= numNodes; i++) {
            sucessores[i].add(new Edge(i,numNodes+i,capacity[i]));
            sucessores[numNodes+i].add(new Edge(numNodes+i,i,0));
            sucessores[0].add(new Edge(0,i,population[i]));
            sucessores[i].add(new Edge(i,0,0));
        }
    }

    public void addRule(int source, int destination) {
        // i -> original
        // i + 1 -> original'
        sucessores[source+numNodes].add(new Edge(source+numNodes,destination,INF)); //2' -> 4
        sucessores[destination].add(new Edge(destination,source+numNodes,0));
        sucessores[destination+numNodes].add(new Edge(destination+numNodes,source,INF)); //4' -> 2
        sucessores[source].add(new Edge(source,destination+numNodes,0));

    }

    public int solve(int sink) {
        //buildNetwork();
        int source = 0;
        int numNodes = sucessores.length;

        // Java já mete tudo a zeros
        int[][] flow = new int[numNodes][numNodes];

        int[] via = new int[numNodes];
        int flowValue = 0;
        int increment;

        while((increment = findPath(flow,source,sink,via)) != 0) {
            flowValue += increment;
            // Update flow
            int node = sink;
            while(node != source) {
                int origin = via[node];
                flow[origin][node] += increment;
                flow[node][origin] -= increment;
                node = origin;
            }
        }

        return flowValue;
        }
        
        
    private int findPath(int[][] flow, int source, int sink, int[] via) {

        int numNodes = regions;

        Queue<Integer> waiting = new LinkedList<Integer>();

        boolean[] found = new boolean[numNodes];

        int[] pathIncr = new int[numNodes];

        waiting.add(source);
        
        found[source] = true;

        via[source] = source;

        pathIncr[source] = INF;

        do {

            int origin = waiting.remove();

            for(Edge e : sucessores[origin]) {
                int destin = e.getDestination();
                int residue = e.getCost() - flow[origin][destin];
                if(!found[destin] && residue > 0) {
                    via[destin] = origin;
                    pathIncr[destin] = Math.min(pathIncr[origin], residue);
                    if(destin == sink)
                        return pathIncr[destin];
                    waiting.add(destin);
                    found[destin] = true;
                }
            }


        } while(!waiting.isEmpty());
        return 0;
    }
  
}
