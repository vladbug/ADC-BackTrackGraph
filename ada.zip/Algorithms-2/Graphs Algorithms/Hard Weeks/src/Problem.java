import java.util.*;
import java.lang.*;

public class Problem {

    List<Integer>[] sucessores;
    int[] inDegree;
    Queue<Integer> current_week;
    Queue<Integer> next_week;

    private int limit;

    private int max;

    private int hard_weeks;

    @SuppressWarnings("unchecked")
    public Problem(int tasks, int limit) {

        sucessores = new List[tasks];
        inDegree = new int[tasks]; // ja fica co m zeros
        current_week = new LinkedList<>();
        next_week = new LinkedList<>();
        this.limit = limit;
        hard_weeks = 0;
        max = Integer.MIN_VALUE;
    

        // Importante fazer assim !
        for(int i = 0; i < tasks; i++) {
            sucessores[i] = new LinkedList<Integer>();
        }


    }

    public void addRule(int source, int destination) {
        sucessores[source].add(destination);
        inDegree[destination]++;
    }

    private void calculateFirstWeek() {

        for(int i = 0; i < inDegree.length; i++) {
            if(inDegree[i] == 0) {
                current_week.add(i);
            }
        }

        if(current_week.size() > max) {
            max = current_week.size();
        }

        if(current_week.size() > limit) {
            hard_weeks++;
        }


    }






    public void solve() {

        calculateFirstWeek();

        
        while(!current_week.isEmpty()) {
            

            // stuff?
            int x = current_week.remove();
            // stuff?

            for(Integer y : sucessores[x]) {
                // Delete the edge
                inDegree[y]--;
                if(inDegree[y] == 0) {
                    next_week.add(y); // preparar para a prox semana
                }
            }

            if(current_week.isEmpty()) {

                Queue<Integer> temp = current_week;
                current_week = next_week;
                next_week = temp;

                if(current_week.size() > max) {
                    max = current_week.size();
                }
        
                if(current_week.size() > limit) {
                    hard_weeks++;
                }

            }


            
        }

    }

    public int getMax() {
        return max;
    }

    public int getHardWeeks() {
        return hard_weeks;
    }



    
}
