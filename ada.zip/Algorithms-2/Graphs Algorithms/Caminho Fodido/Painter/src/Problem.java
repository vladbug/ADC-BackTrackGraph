import java.util.*;

public class Problem {

    private List<Pair> points;
    private Map<Integer,Integer> codeMap;
    private int counter;
    UnionFind partição;

    public Problem(int nSegments) {


        int domainSize = 2 * nSegments;
        this.points = new LinkedList<>();
        this.codeMap = new HashMap<>();
        this.counter = 0;
        this.partição = new UnionFindInArray(domainSize);

    }

    public int hashPoint(Pair p) {
        return 1000 * p.getX() + p.getY();
    }

    public void addPoint(Pair p) {
        points.add(p); // é tipo um saco
        int key = hashPoint(p);
        Integer res = codeMap.get(key);

        if(res == null) {
            codeMap.put(key,this.counter);
            this.counter++;
        }
    }

    public int paint() {
        int counter = 0;
        ListIterator<Pair> it = this.points.listIterator();


        while(it.hasNext()) {
            Pair p1 = it.next();
            Pair p2 = it.next();
            int code1 = codeMap.get(hashPoint(p1));
            int code2 = codeMap.get(hashPoint(p2));

            int rep1 = partição.find(code1);
            int rep2 = partição.find(code2);

            if(rep1 != rep2) {
                counter++;
                partição.union(rep1, rep2);
            }

        }

        return counter;
    }

    
}
