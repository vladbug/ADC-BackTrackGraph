import java.io.*;


public class App {
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] param = reader.readLine().split(" ");

        int minBound = Integer.parseInt(param[0]);
        int maxBound = Integer.parseInt(param[1]);
        int employees = Integer.parseInt(param[2]);
        int nr_edges = Integer.parseInt(param[3]);
        Problem d = new Problem(employees, minBound, maxBound);

        // Now let's fill
        for(int i = 0; i < nr_edges; i++) {
            String[] in = reader.readLine().split(" ");
            d.addRule(Integer.parseInt(in[0]),Integer.parseInt(in[1]));
        }

        

    }
}

// Ao lermos o 7 montamos em memoria um vetor para sucessores
// com 7 posições
// Nos etiquetados com inteiros e o peso sao inteiros
// 0 construimos array diretamente
// 1 construimos array com 8 empregados para queimar 0
// para andar a meter -1 , -1 , -1 , - 1.

// Montamos um segundo de predesucessores tmb com 7 posições

// Ao ler o input temos que ter estas listas ligasdas
// fazer BFS sobre estes vetores
// fazer DFS traversal que o usa o explroer
// DFS traversal faz 1 percurso por grafo, vamos lançar
// varios DFS traversal

// array de booleanos procceded, permite que o percurso termine
// varios DFS C é apanhado com sucessore de A e de B.
// como fazemos para A reinicializamos os processed
// e reiniciamos em B 

// Isto acontence pois A e B ambos apanham C

