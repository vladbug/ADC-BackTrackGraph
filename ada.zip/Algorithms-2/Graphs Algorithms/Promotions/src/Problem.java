import java.util.*;

public class Problem {

    // min promotions
    // max promotions
    // nr_empregados
    // numero de arcos

    private int lowerBound,upperBound,empregados;

    List<Integer>[] successors, predecessors;

    @SuppressWarnings("unchecked")
    public Problem(int empregados, int lowerBound, int upperBound) {

        successors = new List[empregados];
        predecessors = new List[empregados];

        this.empregados = empregados;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;

        // Importante fazer assim !
        for(int i = 0; i < empregados; i++) {
            successors[i] = new LinkedList<Integer>();
            predecessors[i] = new LinkedList<Integer>();
        }

    }

    public void addRule(int source, int destination) {
        successors[source].add(destination);
        predecessors[destination].add(source);
    }

    public int dfs(boolean[] processed, int root) {

        int res = 0;

        processed[root] = true;

        for(Integer a : predecessors[root]) {

            if(!processed[a]) {
                res += 1 + dfs(processed, a);
            }
        }

        return res;

    }

    





    // Desafio : fazer tudo só com os sucessores
    // Temporal não melhora nada mas melhora na espacial








    
}
