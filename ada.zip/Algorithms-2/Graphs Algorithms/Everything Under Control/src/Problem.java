import java.util.*;

public class Problem {

   

    private int nodes;
    private int number_of_edges;
    private int[] weightPath;
    private int [] inDegree;
    private List<Edge> graph;


    @SuppressWarnings("unchecked")
    public Problem(int nodes,int number_of_edges) {
        
       
        this.nodes = nodes;
        this.number_of_edges = number_of_edges;
        this.graph = new List[nodes + 1]; // para comer o zero
        this.weightPath = new int[nodes +1];
        this.inDegree = new int[nodes + 1];
        // Importante fazer assim !
        for(int i = 0; i < nodes; i++) {
            graph[i] = new LinkedList<Edge>();
        }

    }

    public void addSucc(int origin, int destination, int weight) {

    }

    

    private void topoSort() {
        // Queue<>() = firstMoments();
    }

    //destination
    
}
