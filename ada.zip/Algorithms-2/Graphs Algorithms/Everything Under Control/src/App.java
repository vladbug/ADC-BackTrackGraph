import java.io.*;

public class App {
    public static void main(String[] args) throws Exception {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] param = reader.readLine().split(" ");

        int number_of_tasks = Integer.parseInt(param[0]);
        int number_of_edges = Integer.parseInt(param[1]);

        


    }
}
